package gefp.model;

public class TempStage {

	private Integer planid;
	private String sname;
	private String pname;
	private int stageid;
	private int fpstid;
	
	public int getStageid() {
		return stageid;
	}
	public void setStageid(int stageid) {
		this.stageid = stageid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Integer getPlanid() {
		return planid;
	}
	public void setPlanid(Integer planid) {
		this.planid = planid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getFpstid() {
		return fpstid;
	}
	public void setFpstid(int fpstid) {
		this.fpstid = fpstid;
	}
	
	
}
