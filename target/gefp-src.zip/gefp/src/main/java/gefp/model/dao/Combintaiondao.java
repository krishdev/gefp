package gefp.model.dao;
import gefp.model.Combination;
import gefp.model.User;
import gefp.model.FlightPlanDetails;
import java.util.List;
public interface Combintaiondao {

	Combination getcombinationid(Integer id);
	List<Combination> getcombinationids( User name);
	List<Combination> getcombinationidsfor2nduser( User name);
	List<Combination> getsizeofcombinationsforusers( User name);
	
	
	//List<FlightPlanDetails> getsizeofflightplan( User name);
}
